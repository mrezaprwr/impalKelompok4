/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing;

import java.util.Date;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author igustiagunggedenandaraditya
 */


import testing.hotel;


public class HotelTest {

	private hotel hotel;

	@Before
	public void initialize() {
		hotel = new Hotel(new HotelRepositoryImpl());
	}

	@Test
	public void shouldFindCheapestRate() {
		try {
			Assert.assertNotNull("Hotel should be the cheapest rate", hotel);
		} catch (Exception e) {
			Assert.fail();
			e.printStackTrace();
		}
	}

	@Test
	public void shouldNotFindAnything() {
		try {
			// TODO: Implementar teste range de datas.
		} catch (Exception e) {
			Assert.fail();
			e.printStackTrace();
		}
	}

	@Test
	public void shouldDateRangeFail() {
		try {
			// TODO: Implementar teste range de datas.
		} catch (Exception e) {
			Assert.fail();
			e.printStackTrace();
		}
	}

}