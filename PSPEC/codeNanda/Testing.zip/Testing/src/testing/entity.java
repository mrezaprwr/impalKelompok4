/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing;

public interface entity {

  /**
   * If entity is now being managed!
   *
   * @return true if the entity is now being managed.
   */
  boolean isManaged();

}
